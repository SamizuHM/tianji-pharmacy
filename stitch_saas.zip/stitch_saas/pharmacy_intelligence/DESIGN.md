---
name: Pharmacy Intelligence
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e5'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf9'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e1e2ed'
  on-surface: '#191b23'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e1e2ed'
typography:
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  h2:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  table-header:
    fontFamily: Work Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  card-gap: 16px
  table-cell-padding: 12px 16px
  sidebar-width: 240px
---

## Brand & Style

This design system is engineered for a specialized B2B SaaS environment catering to pharmacy store operations. It embodies a **Corporate/Modern** design style with a distinct "Medical Technology" edge. The brand personality is rooted in three pillars: **Expertise**, **Efficiency**, and **Reliability**.

The UI evokes an emotional response of organized control. By utilizing a structured, card-based layout and a sophisticated indigo-to-violet gradient sidebar, the system differentiates itself from generic office software. It leverages subtle AI-inspired accents—such as glassmorphic highlights and glowing status micro-indicators—to signal the intelligent nature of the Q&A engine without veering into futuristic tropes. The aesthetic is "Production-Ready": clean, high-density, and focused on reducing cognitive load for pharmacy staff managing complex medical queries.

## Colors

The color palette is built on a foundation of "Enterprise Blue" to establish immediate trust. The primary interface uses a **light mode** with a high-contrast neutral palette to ensure legibility during long shifts.

The sidebar utilizes a deep gradient transition from **Deep Blue (#0F172A)** to **Indigo/Violet (#1E1B4B)**, providing a premium anchor for the application. Secondary surfaces use a light grey-blue tint (#F1F5F9) to provide depth between cards and the main canvas. Status colors are saturated and industry-standard, ensuring that "Escalated" (Purple) or "Warning" (Orange) items are instantly identifiable in high-density data tables.

## Typography

The typography system prioritizes Simplified Chinese legibility. **Inter** is the primary typeface for its neutral, highly readable characteristics in digital interfaces, paired with **Work Sans** for labels and data-heavy metrics to provide a slightly more technical, grounded feel.

Information hierarchy is strictly enforced through weight and color rather than excessive size differences. Body text defaults to 14px for optimal balance between information density and eye strain. Technical metadata, such as work order IDs and timestamps, utilize the smaller `body-sm` or `label-md` styles to keep the interface lean.

## Layout & Spacing

The system follows a strict **8pt grid system**. The layout uses a **fluid-width** model for content areas while maintaining a **fixed-width sidebar** at 240px. 

Content is organized into a **CARD-based layout**. Each functional module (Statistics, Filters, Tables) is encapsulated in a card. This allows for clear visual separation on the light grey-blue background. For high-density tables, vertical padding is tightened to 12px to maximize the number of visible rows, while horizontal margins remain at 24px to ensure the interface feels professional and breathable.

## Elevation & Depth

Hierarchy is established through **Ambient Shadows** and **Tonal Layers**.
- **Level 0 (Background):** Solid #F1F5F9.
- **Level 1 (Cards/Sidebar):** White surfaces with a soft, diffused shadow (`0px 4px 20px rgba(0, 0, 0, 0.05)`).
- **Level 2 (Modals/Detail Panels):** Higher elevation with a more pronounced shadow (`0px 12px 32px rgba(0, 0, 0, 0.1)`) and a subtle 1px border (#E2E8F0) to ensure separation from the background.

Detail panels and tooltips utilize a light backdrop blur (12px) when appearing over content to maintain focus without losing context of the underlying data.

## Shapes

The shape language is **Soft (0.25rem)**, leaning towards a precise, medical-instrument aesthetic.
- **Buttons and Inputs:** 4px (0.25rem) corner radius for a sharp, professional look.
- **Cards and Detail Panels:** 8px (0.5rem) corner radius to provide a softer container for data.
- **Status Tags:** 4px radius or fully rounded pill-shape depending on the context (pill for high-priority status, square-round for category tags).
- **AI Accents:** Occasional use of "Soft" rounded corners on imagery and icons to indicate the "Intelligent" component of the system.

## Components

- **Sidebar:** Dark gradient background. Active states should use a glassmorphic highlight (semi-transparent white with blur) or a solid brand-blue indicator on the left edge.
- **Buttons:** Primary buttons are solid Enterprise Blue. Secondary buttons use a subtle light-blue ghost style. "Action" buttons in tables (e.g., "View Details") should be text-based with a subtle underline or hover background change to keep the UI clean.
- **Status Tags:** Background colors should be highly desaturated versions of the status color (e.g., 10% opacity) with the text being the full-saturation color for maximum readability.
- **High-Density Tables:** Alternating row highlights are unnecessary; instead, use thin 1px horizontal dividers (#E2E8F0). The header should have a distinct, slightly darker background tint (#F8FAFC).
- **Multi-modal Detail Panels:** These slide in from the right. They should be partitioned into clear sections (Basic Info, Interaction Timeline, Related Documents) using subtle dividers or card-in-panel nesting.
- **AI Chat Bubbles:** In the Q&A workbench, AI-generated responses should be distinguished by a very light violet background or a small "AI" sparkle icon to verify the source of the information.